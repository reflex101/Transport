AOS.init();


$(function () {
    $('.hamburger-menu').on('click' , function (){
        $('.toggle').toggleClass('open');
        $('.nav-list').toggleClass('open');
    })
});

$('#dtBasicExample').mdbEditor({
    mdbEditor: true
    });
    $('.dataTables_length').addClass('bs-select');

    